using System;

namespace ec3k_gateway
{
	public class log
	{
		public log ()
		{
		}
		public static void addLog(string s){
			System.Console.WriteLine(s);
		}
	}
}

