<?

include ('gauge.class.php');
$gauge = new gauge();
$gauge->setPos(85);
$gauge->setLegend('SALES');
$gauge->plot();

?>
